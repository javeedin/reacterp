export interface ElectronAPI {
  showNotification: (title: string, body: string) => void;
  sendOtpEmail: (to: string, otp: string) => Promise<{ success: boolean; error?: string }>;

  // Screen recording
  getScreenSources: () => Promise<Array<{ id: string; name: string; thumbnail: string }>>;
  saveRecording: (buffer: ArrayBuffer, metadata: {
    title: string; description: string; category: string;
    duration: number; createdBy: string;
  }) => Promise<{ success: boolean; id: string; filePath: string }>;

  // Training library
  listRecordings: () => Promise<Array<{
    id: string; title: string; description: string; category: string;
    filePath: string; fileName: string; duration: number;
    fileSize: number; createdAt: string; createdBy: string;
  }>>;
  deleteRecording: (id: string, filePath: string) => Promise<{ success: boolean }>;
  openRecordingsFolder: () => Promise<void>;
  getFileUrl: (filePath: string) => Promise<string>;

  // Session
  saveErpSession: (user: object, token: string) => Promise<{ success: boolean }>;
  getErpSession: () => Promise<{ user: object; token: string } | null>;
  clearErpSession: () => Promise<{ success: boolean }>;

  // Oracle Fusion credentials
  saveFusionCredentials: (username: string, password: string) => Promise<{ success: boolean }>;
  getFusionCredentials: () => Promise<{ username: string; password: string } | null>;
  clearFusionCredentials: () => Promise<{ success: boolean }>;

  isElectron: boolean;
  platform: string;
}

declare global {
  interface Window {
    electronAPI?: ElectronAPI;
  }
}

export {};
