import React, { useState } from 'react';
import { Layout, Space, Typography, Tooltip, Button } from 'antd';
import {
  PlaySquareOutlined, GlobalOutlined, EyeOutlined, VideoCameraOutlined,
} from '@ant-design/icons';
import { useNavigate, useLocation } from 'react-router-dom';
import { ShowAndTellPanel } from '../features/showAndTell';
import ScreenRecorder from '../components/ScreenRecorder';

const { Header, Content } = Layout;
const { Text } = Typography;

const REDWOOD = '#C74634';

const MainLayout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const navigate  = useNavigate();
  const location  = useLocation();
  const [showAndTellOpen, setShowAndTellOpen] = useState(false);

  const navBtn = (path: string, icon: React.ReactNode, label: string) => {
    const active = location.pathname.startsWith(path);
    return (
      <Tooltip title={label} placement="bottom">
        <Button
          type={active ? 'primary' : 'text'}
          icon={icon}
          style={{
            color: active ? '#fff' : REDWOOD,
            background: active ? REDWOOD : 'transparent',
            borderColor: active ? REDWOOD : 'transparent',
            fontWeight: active ? 600 : 400,
          }}
          onClick={() => navigate(path)}
        >
          {label}
        </Button>
      </Tooltip>
    );
  };

  return (
    <Layout style={{ minHeight: '100vh' }}>
      <Header style={{
        background: '#fff',
        borderBottom: `2px solid ${REDWOOD}`,
        display: 'flex',
        alignItems: 'center',
        padding: '0 16px',
        gap: 8,
        position: 'sticky',
        top: 0,
        zIndex: 100,
      }}>
        {/* Logo */}
        <div style={{ marginRight: 24, display: 'flex', alignItems: 'center', gap: 8 }}>
          <div style={{ width: 28, height: 28, background: REDWOOD, borderRadius: 6, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <VideoCameraOutlined style={{ color: '#fff', fontSize: 16 }} />
          </div>
          <Text strong style={{ fontSize: 16, color: REDWOOD, letterSpacing: '-0.3px' }}>ERP Studio</Text>
        </div>

        {/* Navigation */}
        <Space size={4}>
          {navBtn('/oracle-fusion', <GlobalOutlined />,     'Oracle Fusion')}
          {navBtn('/training',      <PlaySquareOutlined />, 'Training Library')}
        </Space>

        {/* Right toolbar */}
        <div style={{ marginLeft: 'auto', display: 'flex', alignItems: 'center', gap: 8 }}>
          <ScreenRecorder />
          <Tooltip title="Show & Tell — guided tours" placement="bottom">
            <Button
              type="text"
              icon={<EyeOutlined />}
              style={{ color: REDWOOD }}
              onClick={() => setShowAndTellOpen(true)}
            >
              Show &amp; Tell
            </Button>
          </Tooltip>
        </div>
      </Header>

      <Content style={{ background: '#f5f5f5' }}>
        {children}
      </Content>

      <ShowAndTellPanel open={showAndTellOpen} onClose={() => setShowAndTellOpen(false)} />
    </Layout>
  );
};

export default MainLayout;
